package tresenrayag;

public class TresEnRayaG {
    public static void main(String[] args)
    {
        new Menu().setVisible(true);
    }
}