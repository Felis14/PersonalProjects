package tresenrayag;

import java.awt.Color;
import javax.swing.ImageIcon;

public class Menu extends javax.swing.JFrame {
    
    static int winsX, winsO, winsNo, partidas, WinsP, WinsC, Cempate, partidasC;
    static boolean JvsC = false;
    
    public Menu() {
        initComponents();
        
        this.setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("GatoIcon.png")).getImage());
        
        JJButton.hide();
        JCButton.hide();
        BackButton.hide();
        SalirText.hide();
        ExitYesButton.hide();
        NoExitButton.hide();
        
        winsX = (Juego.Xwin);
        winsO = (Juego.Owin);
        winsNo = (Juego.Nowin);
        partidas = (Juego.games);
        WinsP = (Juego.winsP);
        WinsC = (Juego.winsC);
        Cempate = (Juego.empateC);
        partidasC = (Juego.partidasC);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Menucillo = new javax.swing.JPanel();
        GatoText = new javax.swing.JLabel();
        GatoIMG = new javax.swing.JLabel();
        BackButton = new javax.swing.JButton();
        JJButton = new javax.swing.JButton();
        JCButton = new javax.swing.JButton();
        PlayButton = new javax.swing.JButton();
        SalirText = new javax.swing.JLabel();
        ExitButton = new javax.swing.JButton();
        NoExitButton = new javax.swing.JButton();
        ExitYesButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menucillo.setBackground(new java.awt.Color(0, 0, 0));
        Menucillo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        GatoText.setFont(new java.awt.Font("LEMON MILK", 0, 48)); // NOI18N
        GatoText.setForeground(new java.awt.Color(255, 255, 255));
        GatoText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        GatoText.setText("GATO");
        Menucillo.add(GatoText, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 580, 60));

        GatoIMG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        GatoIMG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tresenrayag/GatoIcon.png"))); // NOI18N
        Menucillo.add(GatoIMG, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, 140, 100));

        BackButton.setBackground(new java.awt.Color(0, 0, 0));
        BackButton.setFont(new java.awt.Font("LEMON MILK", 0, 24)); // NOI18N
        BackButton.setForeground(new java.awt.Color(255, 255, 255));
        BackButton.setText("Volver");
        BackButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BackButton.setFocusPainted(false);
        BackButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BackButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BackButtonMouseExited(evt);
            }
        });
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        Menucillo.add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 270, 160, 40));

        JJButton.setBackground(new java.awt.Color(0, 0, 0));
        JJButton.setFont(new java.awt.Font("LEMON MILK", 0, 11)); // NOI18N
        JJButton.setForeground(new java.awt.Color(255, 255, 255));
        JJButton.setText("Jugador vs Jugador");
        JJButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JJButton.setFocusPainted(false);
        JJButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JJButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JJButtonMouseExited(evt);
            }
        });
        JJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JJButtonActionPerformed(evt);
            }
        });
        Menucillo.add(JJButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 180, 40));

        JCButton.setBackground(new java.awt.Color(0, 0, 0));
        JCButton.setFont(new java.awt.Font("LEMON MILK", 0, 11)); // NOI18N
        JCButton.setForeground(new java.awt.Color(255, 255, 255));
        JCButton.setText("Jugador vs Consola");
        JCButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JCButton.setFocusPainted(false);
        JCButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JCButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JCButtonMouseExited(evt);
            }
        });
        JCButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JCButtonActionPerformed(evt);
            }
        });
        Menucillo.add(JCButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 127, 180, 40));

        PlayButton.setBackground(new java.awt.Color(0, 0, 0));
        PlayButton.setFont(new java.awt.Font("LEMON MILK", 0, 24)); // NOI18N
        PlayButton.setForeground(new java.awt.Color(255, 255, 255));
        PlayButton.setText("Jugar");
        PlayButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        PlayButton.setFocusPainted(false);
        PlayButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PlayButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PlayButtonMouseExited(evt);
            }
        });
        PlayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlayButtonActionPerformed(evt);
            }
        });
        Menucillo.add(PlayButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 270, 160, 40));

        SalirText.setBackground(new java.awt.Color(0, 0, 0));
        SalirText.setFont(new java.awt.Font("LEMON MILK", 0, 16)); // NOI18N
        SalirText.setForeground(new java.awt.Color(255, 255, 255));
        SalirText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SalirText.setText("¿Salir?");
        SalirText.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        Menucillo.add(SalirText, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 320, 80, 30));

        ExitButton.setBackground(new java.awt.Color(0, 0, 0));
        ExitButton.setFont(new java.awt.Font("LEMON MILK", 0, 24)); // NOI18N
        ExitButton.setForeground(new java.awt.Color(255, 255, 255));
        ExitButton.setText("Salir");
        ExitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ExitButton.setFocusPainted(false);
        ExitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitButtonMouseExited(evt);
            }
        });
        ExitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitButtonActionPerformed(evt);
            }
        });
        Menucillo.add(ExitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 350, 160, 40));

        NoExitButton.setBackground(new java.awt.Color(0, 0, 0));
        NoExitButton.setFont(new java.awt.Font("LEMON MILK", 0, 16)); // NOI18N
        NoExitButton.setForeground(new java.awt.Color(255, 255, 255));
        NoExitButton.setText("NO");
        NoExitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        NoExitButton.setFocusPainted(false);
        NoExitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                NoExitButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                NoExitButtonMouseExited(evt);
            }
        });
        NoExitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoExitButtonActionPerformed(evt);
            }
        });
        Menucillo.add(NoExitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 390, 70, 30));

        ExitYesButton.setBackground(new java.awt.Color(0, 0, 0));
        ExitYesButton.setFont(new java.awt.Font("LEMON MILK", 0, 16)); // NOI18N
        ExitYesButton.setForeground(new java.awt.Color(255, 255, 255));
        ExitYesButton.setText("Sí");
        ExitYesButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ExitYesButton.setFocusPainted(false);
        ExitYesButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitYesButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitYesButtonMouseExited(evt);
            }
        });
        ExitYesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitYesButtonActionPerformed(evt);
            }
        });
        Menucillo.add(ExitYesButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 390, 70, 30));

        getContentPane().add(Menucillo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JJButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JJButtonMouseEntered
        JJButton.setBackground(Color.white);
        JJButton.setForeground(Color.black);
    }//GEN-LAST:event_JJButtonMouseEntered

    private void JJButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JJButtonMouseExited
        JJButton.setBackground(Color.black);
        JJButton.setForeground(Color.white);
    }//GEN-LAST:event_JJButtonMouseExited

    private void JCButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JCButtonMouseEntered
        JCButton.setBackground(Color.white);
        JCButton.setForeground(Color.black);
    }//GEN-LAST:event_JCButtonMouseEntered

    private void JCButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JCButtonMouseExited
        JCButton.setBackground(Color.black);
        JCButton.setForeground(Color.white);
    }//GEN-LAST:event_JCButtonMouseExited

    private void BackButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackButtonMouseEntered
        BackButton.setBackground(Color.white);
        BackButton.setForeground(Color.black);
    }//GEN-LAST:event_BackButtonMouseEntered

    private void BackButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackButtonMouseExited
        BackButton.setBackground(Color.black);
        BackButton.setForeground(Color.white);
    }//GEN-LAST:event_BackButtonMouseExited

    private void PlayButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PlayButtonMouseEntered
        PlayButton.setBackground(Color.white);
        PlayButton.setForeground(Color.black);
    }//GEN-LAST:event_PlayButtonMouseEntered

    private void PlayButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PlayButtonMouseExited
        PlayButton.setBackground(Color.black);
        PlayButton.setForeground(Color.white);
    }//GEN-LAST:event_PlayButtonMouseExited

    private void ExitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitButtonMouseEntered
        ExitButton.setBackground(Color.white);
        ExitButton.setForeground(Color.black);
    }//GEN-LAST:event_ExitButtonMouseEntered

    private void ExitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitButtonMouseExited
        ExitButton.setBackground(Color.black);
        ExitButton.setForeground(Color.white);
    }//GEN-LAST:event_ExitButtonMouseExited

    private void ExitYesButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitYesButtonMouseEntered
        ExitYesButton.setBackground(Color.white);
        ExitYesButton.setForeground(Color.black);
    }//GEN-LAST:event_ExitYesButtonMouseEntered

    private void ExitYesButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitYesButtonMouseExited
        ExitYesButton.setBackground(Color.black);
        ExitYesButton.setForeground(Color.white);
    }//GEN-LAST:event_ExitYesButtonMouseExited

    private void NoExitButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoExitButtonMouseEntered
        NoExitButton.setBackground(Color.white);
        NoExitButton.setForeground(Color.black);
    }//GEN-LAST:event_NoExitButtonMouseEntered

    private void NoExitButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoExitButtonMouseExited
        NoExitButton.setBackground(Color.black);
        NoExitButton.setForeground(Color.white);
    }//GEN-LAST:event_NoExitButtonMouseExited

    private void JJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JJButtonActionPerformed
        JvsC = false;
        this.setVisible(false);
        Juego mostrar = new Juego();
        mostrar.setVisible(true);
    }//GEN-LAST:event_JJButtonActionPerformed

    private void ExitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitButtonActionPerformed
        NoExitButton.show();
        ExitYesButton.show();
        PlayButton.hide();
        SalirText.show();
        ExitButton.hide();
    }//GEN-LAST:event_ExitButtonActionPerformed

    private void NoExitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NoExitButtonActionPerformed
        NoExitButton.hide();
        ExitYesButton.hide();
        PlayButton.show();
        SalirText.hide();
        ExitButton.show();
    }//GEN-LAST:event_NoExitButtonActionPerformed

    private void ExitYesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitYesButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitYesButtonActionPerformed

    private void PlayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlayButtonActionPerformed
        PlayButton.hide();
        ExitButton.hide();
        BackButton.show();
        JJButton.show();
        JCButton.show();
        GatoText.setText("Modo de juego");
    }//GEN-LAST:event_PlayButtonActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        PlayButton.show();
        ExitButton.show();
        BackButton.hide();
        JJButton.hide();
        JCButton.hide();
        GatoText.setText("Gato");
    }//GEN-LAST:event_BackButtonActionPerformed

    private void JCButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JCButtonActionPerformed
        JvsC = true;
        this.setVisible(false);
        Juego mostrar = new Juego();
        mostrar.setVisible(true);
    }//GEN-LAST:event_JCButtonActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton BackButton;
    public static javax.swing.JButton ExitButton;
    public static javax.swing.JButton ExitYesButton;
    private javax.swing.JLabel GatoIMG;
    public static javax.swing.JLabel GatoText;
    public static javax.swing.JButton JCButton;
    public static javax.swing.JButton JJButton;
    private javax.swing.JPanel Menucillo;
    public static javax.swing.JButton NoExitButton;
    public static javax.swing.JButton PlayButton;
    public static javax.swing.JLabel SalirText;
    // End of variables declaration//GEN-END:variables
}
